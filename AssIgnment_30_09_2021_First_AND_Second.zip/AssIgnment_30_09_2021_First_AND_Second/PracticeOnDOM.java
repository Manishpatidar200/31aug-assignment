/*
1. Create an xml document with following details.

    Subject,
    Questions for Subject
    Options for Questions with information of correct option


  using Java DOM API.

2. Read above xml document created using Java DOM parsers
*/

//////////////////  FIRST QUESTION CODE///////////////////
package AssIgnment_30_09_2021_First_AND_Second;

import java.io.File;
import javax.lang.model.element.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;

public class PracticeOnDOM {
	public static void main(String[] args) throws ParserConfigurationException, TransformerException
	{
	
	File xmlFile = new File("D:\\programforTraining\\CoreJavaAssignment\\src\\AssIgnment_30_09_2021_First_AND_Second//questionPaper.xml");
	
	DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
	DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
	Document document=documentBuilder.newDocument();
	
	org.w3c.dom.Element subject = document.createElement("Subject");
	subject.setAttribute("SubjectName", "Java");
	document.appendChild(subject);
	
	org.w3c.dom.Element quiz = document.createElement("Quiz");
	quiz.setAttribute("Quiz Name", "Java 1");
	document.appendChild(quiz);
	
	Attr question1 =  document.createAttribute("Question 1");
	question1.setValue("Is Java an Object Oriented Programming?"+
	"\n a.Yes b.No");
	quiz.setAttributeNode(question1);
	
	Attr question2 =  document.createAttribute("Question 2");
	question1.setValue("Does Java support Multiple Inheritence?"+
	"\n a.Yes b.No");
	quiz.setAttributeNode(question2);
	
	Attr question3 =  document.createAttribute("Question 3");
	question1.setValue("Is Java platform independant?"+
	"\n a.Yes b.No");
	quiz.setAttributeNode(question3);
	
	Attr question4 =  document.createAttribute("Question 4");
	question1.setValue("Is Java used for creating Enterprise application"+
	"\n a.Yes b.No");
	quiz.setAttributeNode(question4);
	
	org.w3c.dom.Element Java1Answer = document.createElement("Java 1 Answers");
	Java1Answer.setAttribute("Q No.", "Answer");
	document.appendChild(Java1Answer);
	
	Attr Answer1= document.createAttribute("Answer 1");
	Answer1.setValue("a");
	Java1Answer.setAttributeNode(Answer1);
	
	Attr Answer2= document.createAttribute("Answer 2");
	Answer2.setValue("b");
	Java1Answer.setAttributeNode(Answer2);
	
	Attr Answer3= document.createAttribute("Answer 3");
	Answer3.setValue("a");
	Java1Answer.setAttributeNode(Answer3);
	
	Attr Answer4= document.createAttribute("Answer 4");
	Answer4.setValue("a");
	Java1Answer.setAttributeNode(Answer4);
	
	TransformerFactory transformerFactory=TransformerFactory.newInstance();
	Transformer transformer=transformerFactory.newTransformer();
	
	DOMSource domSource=new DOMSource(document);
	
	StreamResult streamResult=new StreamResult(xmlFile);
	
	transformer.transform(domSource, streamResult);
	
	
	}

}
