/*
 * 3. Ask user to enter 6 student records with following attributes

   Roll No
   firstName
   lastName
   age
   semester 1 marks
   semester 2 marks
   semester 3 marks

 display Sorted student details based on age,firstName and lastName in ascending order.

 display Sorted student details based on percentage of semester marks in descending order.

 */
package SeventeenSep2021;

import java.util.Comparator;

public class SortByStudentLastName implements Comparator<Student>{
	public int compare(Student a,Student b) 
	{		
		return a.getLastname().compareToIgnoreCase(b.getLastname());
		
	}

}
  class SortByStudentFirstName implements Comparator<Student>
{
	public int compare(Student a,Student b) 
	{
		return a.getFirstname().compareToIgnoreCase(b.getFirstname());
	}
	
}
  class SortByStudentAge implements Comparator<Student>
  {
	  public int compare(Student a, Student b)
	  {
		  return a.getAge()-(b.getAge());
	  }
  }
  class SortByStudentPercentage implements Comparator<Student>
  {
	  public int compare(Student a, Student b)
	  {
		  return b.getPercentage() - a.getPercentage();
	  }
  }
  