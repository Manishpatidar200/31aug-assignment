/*
 * 3. Ask user to enter 6 student records with following attributes

   Roll No
   firstName
   lastName
   age
   semester 1 marks
   semester 2 marks
   semester 3 marks

 display Sorted student details based on age,firstName and lastName in ascending order.

 display Sorted student details based on percentage of semester marks in descending order.

 */
package SeventeenSep2021;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class UserDetails {
public static ArrayList<Student> list;
    
    public static void PrintStudentDetails() 
    {
    	for(Student st : list)
		{
			System.out.println(st);
		}
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int recordNo=1;
		list = new ArrayList<Student>();
		try (Scanner sc = new Scanner(System.in)) {
			for(int i=0;i<2;i++)
			{
				Student student = new Student();
				System.out.println("Enter Student Data :"+recordNo);
				
				System.out.println("Enter the  Roll Number");
				student.setrollno(sc.nextInt());
				
				System.out.println("Enter student First Name");
				student.setFirstname(sc.next());
				
				System.out.println("Enter student Last Name");
				student.setLastname(sc.next());
				
				System.out.println("Enter student  Age");
				student.setAge(sc.nextInt());
				
				System.out.println("Enter first sem marks");
				student.setFirstSemMarks(sc.nextInt());
				
				System.out.println("Enter Second sem marks");
				student.setSecondSemMarks(sc.nextInt());
				
				System.out.println("Enter third sem marks");
				student.setThirdSemMarks(sc.nextInt());
				
				
				int totalMarks = student.getFirstSemMarks()+student.getSecondSemMarks()+student.getThirdSemMarks();
				int percent = totalMarks/3;
				student.setPercentage(percent);

				
			list.add(student);
			recordNo++;
			}
		}
		         System.out.println("\n student Details");
		         System.out.println("");
		         PrintStudentDetails();
		         System.out.println("");
		         System.out.println("\n Student details Sorted By Age ");
                 Collections.sort(list, new SortByStudentAge());
                 PrintStudentDetails();
                 
                 System.out.println("     ");
                 System.out.println("\n Student Details Sorted By First Name ");
                 Collections.sort(list, new SortByStudentFirstName());
                 PrintStudentDetails();
                 
                 System.out.println("");
                 System.out.println("\n Student Details Sorted By Last Name");
                 Collections.sort(list, new SortByStudentLastName());
                 PrintStudentDetails();
                 
                                
                 System.out.println("");
                 System.out.println("\n Student Record Sorted By Percentage");
                 Collections.sort(list, new SortByStudentPercentage());
                 PrintStudentDetails();
                
	}
}


