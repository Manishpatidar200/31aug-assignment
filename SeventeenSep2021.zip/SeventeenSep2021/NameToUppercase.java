/* 1. Ask user to enter five names

   convert third character in a name to uppercase
*/
package SeventeenSep2021;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

public class NameToUppercase {

	

	public static void main(String[] args) {
		
           Scanner sc= new Scanner(System.in);
          System.out.println("enter the number");
          int n= sc.nextInt();
           System.out.println("enter "+ n + " Strings");
           ArrayList<String>  lst = new ArrayList<>(n);
           ArrayList<String>  lst1 = new ArrayList<>(n);
           for(int i=0;i<n;i++)
           {
        	   lst.add(sc.next());
        	   
           }
           for(int i=0;i<n;i++)
           {
        	   String x= lst.get(i);
        	   for(int str=0;str<x.length();str++)
        	   {
        		   if(str==2)
        		   {
        		   Character c=x.charAt(str);
        		   
        			   String str1=x.replace(c, Character.toUpperCase(c));
        			   lst1.add(str1);
        		   }
        	   }
           }
        	   for(int u=0; u<n ; u++)
        	   {
        	   System.out.println(lst1.get(u));
        	   
        	   }
           
           
           
	}

}
