/*
 * 3. Ask user to enter 6 student records with following attributes

   Roll No
   firstName
   lastName
   age
   semester 1 marks
   semester 2 marks
   semester 3 marks

 display Sorted student details based on age,firstName and lastName in ascending order.

 display Sorted student details based on percentage of semester marks in descending order.

 */
package SeventeenSep2021;

import java.util.Comparator;

public class Student {
	 private String firstname;
	 private String lastname;
	    private int rollno;
	    private int studentage;
	    private int firstSemMarks;
	    private int secondSemMarks;
	    private int thirdSemMarks;
	    private int percentage;
	    
 
	    public Student(int rollno, String firstname, String lastname, int studentage,int firstSemMarks , 
	    		int secondSemMarks, int thirdSemMarks ) {
	        this.rollno = rollno;
	        this.firstname = firstname;
	        this.lastname = lastname;
	        this.studentage = studentage;
	        this.firstSemMarks=firstSemMarks;
		    this.secondSemMarks= secondSemMarks;
		    this.thirdSemMarks= thirdSemMarks;
		  //  this.percentage=percentage;
	    }
	   
	    public Student() {
			// TODO Auto-generated constructor stub
	    	super();
		}

		public int getrollno() {
			return rollno;
		}
		public void setrollno(int rollno) {
			this.rollno = rollno;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public int getAge() {
			return studentage;
		}
		public void setAge(int studentage) {
			this.studentage = studentage;
		}
		public int getFirstSemMarks() {
			return firstSemMarks;
		}
		public void setFirstSemMarks(int firstSemMarks) {
			this.firstSemMarks = firstSemMarks;
		}
		public int getSecondSemMarks() {
			return secondSemMarks;
		}
		public void setSecondSemMarks(int secondSemMarks) {
			this.secondSemMarks = secondSemMarks;
		}
		public int getThirdSemMarks() {
			return thirdSemMarks ;
		}
		public void setThirdSemMarks(int thirdSemMarks) {
			this.thirdSemMarks = thirdSemMarks;
		}
		public int getPercentage() {
			return percentage;
		}
		public void setPercentage(int percentage) {
			this.percentage = percentage;
		}



		@Override
		public String toString() {
			return "Student [rollno = " + rollno + ", StudentfirstName = " + firstname + ",  StudentlastName = " +
		            lastname + ",   StudentAge = "+ studentage + ", FirstsemMarks = " + firstSemMarks + ",   SecondsemMarks = " +
					secondSemMarks + ",   ThirdsemMarks = " + thirdSemMarks+ ",   Percentage = " + percentage + "%]";
		}	  
	}
	    