package Assignment_29_09_2021_First;

import java.io.FileOutputStream;

public class putStudentData {
public static void main(String[] args) throws IOException {
		
		Scanner input = new Scanner(System.in);
		StudentDetails s =new StudentDetails();
		
		double studentPercentage;
		int sum=0;
		
		
		System.out.print("Enter student rollNo:");
		int rollno = input.nextInt();
		s.setsRollNo(rollno);
		
		System.out.print("Enter student Name:");
		String Name = input.next();
		s.setsName(Name);
		
		System.out.println("Enter student marks for sem 1");
		int marks_Sem1 = input.nextInt();
		s.setMarks_sem1(marks_Sem1);
		sum=sum+marks_Sem1;
		
		System.out.println("Enter student marks for sem 2");
		int marks_Sem2 = input.nextInt();
		s.setMarks_sem2(marks_Sem2);
		sum=sum+marks_Sem2;
		
		System.out.println("Enter student marks for sem 3");
		int marks_Sem3 = input.nextInt();
		s.setMarks_sem3(marks_Sem3);
		sum=sum+marks_Sem3;
		
		System.out.println("Enter student marks for sem 4");
		int marks_Sem4 = input.nextInt();
		s.setMarks_sem4(marks_Sem4);
		sum=sum+marks_Sem4;
		
		studentPercentage = (sum/(4*100))*100;
		s.setPercentage(studentPercentage);
		List<StudentDetails> student = new ArrayList<>();
		student.add(s);
		
		
		
		ObjectMapper mapper=new ObjectMapper();
		//serialization
		OutputStream os=new FileOutputStream("D:\\JavaTrainingIO\\student.dat");
		mapper.writeValue(os, student);

		
		

	}

}
