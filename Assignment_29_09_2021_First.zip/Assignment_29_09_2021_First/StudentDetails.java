/*
Ask end user to enter following details 

 Roll no
 Student name
 Semester1 marks
 Semester 2 marks
 Semester 3 Marks
.....

Ask for four entries.

Calculate percentage of marks and store into file student.dat
*/
package Assignment_29_09_2021_First;

public class StudentDetails {
	
	private int sRollNo;
	private String sName;
	private int marks_sem1;
	private int marks_sem2;
	private int marks_sem3;
	private int marks_sem4;
	private double percentage;
	
	public int getsRollNo() {
		return sRollNo;
	}
	public void setsRollNo(int sRollNo) {
		this.sRollNo = sRollNo;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public int getMarks_sem1() {
		return marks_sem1;
	}
	public void setMarks_sem1(int marks_sem1) {
		this.marks_sem1 = marks_sem1;
	}
	public int getMarks_sem2() {
		return marks_sem2;
	}
	public void setMarks_sem2(int marks_sem2) {
		this.marks_sem2 = marks_sem2;
	}
	public int getMarks_sem3() {
		return marks_sem3;
	}
	public void setMarks_sem3(int marks_sem3) {
		this.marks_sem3 = marks_sem3;
	}
	public int getMarks_sem4() {
		return marks_sem4;
	}
	public void setMarks_sem4(int marks_sem4) {
		this.marks_sem4 = marks_sem4;
	}
	
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double studentPercentage) {
		this.percentage = studentPercentage;
	}
	@Override
	public String toString() {
		return "StudentDetails [sRollNo=" + sRollNo + ", sName=" + sName + ", marks_sem1=" + marks_sem1
				+ ", marks_sem2=" + marks_sem2 + ", marks_sem3=" + marks_sem3 + ", marks_sem4=" + marks_sem4
				+ ", percentage=" + percentage + "]";
	}
	
	

}