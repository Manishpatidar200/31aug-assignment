/*
4. Create Category,Subcategory,Product,Item classes and associate them.

   Serialize Category to JSON  
   Deserialze category from JSON and print on console

---------------Sub category CLass-----------------
*/
package Assignment_28_09_2021_Fourth;

import java.io.Serializable;
import java.util.List;

public class SubCategory implements Serializable {
	private static final long serialVersionUID = 1L;
	private String subCategoryId;
	private String subCategoryDescription;
	private List<Product> products;
	
	public SubCategory() {}

	public String getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCategoryDescription() {
		return subCategoryDescription;
	}

	public void setSubCategoryDescription(String subCategoryDescription) {
		this.subCategoryDescription = subCategoryDescription;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "SubCategory [subCategoryId=" + subCategoryId + ", subCategoryDescription=" + subCategoryDescription
				+ ", products=" + products + "]";
	}
	
}
