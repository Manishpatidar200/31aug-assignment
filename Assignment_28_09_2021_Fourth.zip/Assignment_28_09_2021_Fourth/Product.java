/*
4. Create Category,Subcategory,Product,Item classes and associate them.

   Serialize Category to JSON  
   Deserialze category from JSON and print on console

---------------Product CLass-----------------
*/
package Assignment_28_09_2021_Fourth;


import java.io.Serializable;
import java.util.List;

public class Product implements Serializable {
	private static final long serialVersionUID = 1L;
	private String productId;
	private String productDescription;
	private List<Item> items;
	
	public Product() {}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productDescription=" + productDescription + ", items=" + items
				+ "]";
	}
	
}
