package Assignment_06_10_2021_Second;

public class MultithreadingPractice {

}
