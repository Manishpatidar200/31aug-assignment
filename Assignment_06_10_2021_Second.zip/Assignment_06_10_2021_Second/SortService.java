/*write a program to do sorting of multiple arrays using multithreading.


int[] array1={23,34,78,90};
int[] array2={89,23};
int[] array3={12,34,67};

After arrays are sorted print sorted arrays.
*/
package Assignment_06_10_2021_Second;

import java.util.Arrays;
import java.util.concurrent.Callable;

public class SortService implements Callable<Integer[]> {
private Integer arr[];
	
	public SortService(Integer intArray[]) 
	{
		this.arr = intArray;
	}
	
	@Override
	public Integer[] call() throws Exception {
		System.out.println("Sorting Thread :"+Thread.currentThread());
		Arrays.sort(arr);
		return arr;
	}


}
