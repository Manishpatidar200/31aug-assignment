/*
 * Read following xml document data using SAX Parsers.

    <employees>
    <employee>
    <empId>1001</empId>
    <empName>Sabbir</empName>
    <empSalary>34000</empSalary>
    </employee>
    <employee>
    <empId>1002</empId>
    <empName>Rohit</empName>
    <empSalary>94000</empSalary>
    </employee>
    </employees>
    
 */
package Assignment_30_09_2021_Third;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class PracticeOnSAX {
public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		
		File xmlFile=new File("D:\\programforTraining\\CoreJavaAssignment\\src\\Assignment_30_09_2021_Third\\employee.xml");
		InputStream is=ClassLoader.getSystemResourceAsStream("employee.xml");
		
		DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
		//Document document=documentBuilder.parse(xmlFile);
		Document document=documentBuilder.parse(is);
		document.getDocumentElement().normalize();
		String employees=document.getDocumentElement().getNodeName();
		System.out.println("Employees:"+employees);
		
		System.out.println(document.getDocumentElement().getNodeName());
		
		NodeList nodeList=document.getElementsByTagName("employee");
		for(int i=0;i<nodeList.getLength();i++) {
			
			Node node=nodeList.item(i);
			System.out.println(node.getNodeName());
			
			if(node.getNodeType()==Node.ELEMENT_NODE) {
				Element element=(Element)node;
				NodeList empList=element.getElementsByTagName("employee");
				
				for(int j=0;j<empList.getLength();j++) {
					Node empNode=empList.item(j);
					if(empNode.getNodeType()==Node.ELEMENT_NODE) {
						Element empElement=(Element)empNode;
						System.out.println("Employee Id:"+empElement.getAttribute("empId"));
						System.out.println("Employee Name:"+empElement.getAttribute("empName"));
						System.out.println("Employee Salary:"+empElement.getAttribute("empSalary"));
					}
				}
				}

	}

}

}
