/*
  Write  a program to simulate interview process using multithreading.

Use synchronized keyword and Lock,ReentrantLock for properly synchronizing the process.


 */

package Assignment_06_10_2021_First;

public class Interview {
	private String intViewName;
	private String intViewLoc;
	private String intViewBatch;
	
	public Interview(String intViewName, String intViewLoc, String intViewBatch) {
		super();
		this.intViewName = intViewName;
		this.intViewLoc = intViewLoc;
		this.intViewBatch = intViewBatch;
	}
	

}
