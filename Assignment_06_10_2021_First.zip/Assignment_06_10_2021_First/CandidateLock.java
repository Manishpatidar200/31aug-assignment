
/*
  Write  a program to simulate interview process using multithreading.

Use synchronized keyword and Lock,ReentrantLock for properly synchronizing the process.


 */
package Assignment_06_10_2021_First;

import java.util.concurrent.locks.Lock;

public class CandidateLock implements Runnable{
	private String cName;
	private InterviewLock ivLock;
	Lock lock;
	
	public CandidateLock(String cName, InterviewLock ivLock, Lock lock) {
		super();
		this.cName = cName;
		this.ivLock = ivLock;
		this.lock = lock;
	}
	

	@Override
	public void run() {
		
		System.out.println(cName+" waiting int the queue");
		synchronized(ivLock)
		{
	
		lock.lock();
		ivLock.giveInterview(cName);
		lock.unlock();
	}
	}

}
