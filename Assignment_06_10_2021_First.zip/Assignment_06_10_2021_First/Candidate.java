/*
  Write  a program to simulate interview process using multithreading.

Use synchronized keyword and Lock,ReentrantLock for properly synchronizing the process.


 */
package Assignment_06_10_2021_First;

public class Candidate implements Runnable {
	private String cName;
	private Interview intView;
	
	

	public Candidate(String cName, Interview intView) {
		super();
		this.cName = cName;
		this.intView = intView;
	}



	@Override
	public void run() {

		System.out.println(cName+" waiting in queue.");
		
		synchronized(intView)
		{
			System.out.println(cName+" enters into the room.");
			System.out.println(cName+"'s interview is in progress.");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(cName+" has completed interview.");
		}
		
	}


}
