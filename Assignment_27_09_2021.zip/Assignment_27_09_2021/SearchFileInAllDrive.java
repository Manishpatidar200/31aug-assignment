/*Q2. Ask user to enter extension of file on console. Search for all files with that
  extension in all drives of system.
 */
package Assignment_27_09_2021;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class SearchFileInAllDrive {
	static int count =0;

	public static void main(String gg[])
	{
		
		try(Scanner sc=new Scanner(System.in)){
		System.out.println("Enter the file extension...");
		String extension= sc.next();
		File f=new File("D:\\");
		if(f.isDirectory())
		{
			try 
			{
				totalFiles(f,extension);
				
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("File extension is not valid...");
		}
		}
		System.out.println("total number of files are " + count);
	}


	private static void totalFiles(File f, String find) throws IOException 
	{
		// TODO Auto-generated method stub
		File[] listFiles=f.listFiles();
		for (File file : listFiles) {

			if (file.isDirectory()) 
			{
				if (!file.isHidden())
				{
					totalFiles(file, find);
				}
			}
			else if (file.isFile()) 
			{
				if(file.isHidden())
				{
					continue;
				}
				if (file.getName().endsWith(find)) 
				{
				
					System.out.println(count+". "+file.getCanonicalPath());
					count++;
				}
			}
		}

	}
}

		
	

	
