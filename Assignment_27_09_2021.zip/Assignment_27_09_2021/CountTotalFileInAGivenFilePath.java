/*Q1. Count the no. of files in a given folder. Ask end user to add folder path on console and
count the no. of files in that folder.*/

package Assignment_27_09_2021;

import java.io.File;
import java.util.InputMismatchException;
import java.util.Scanner;

public class CountTotalFileInAGivenFilePath {

	//private static System system;

	public static void main(String[] args) {
		String filePath=null;
		try {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the file Path..");
			 filePath=sc.next();
			
		}
		catch(InputMismatchException e)
		{
			System.out.println("Path is invalid please Enter again a Specific path....");
		}
		File folderPath= new File(filePath);
		if(folderPath.isDirectory()==true)
		{
			System.out.println("folder Path is valid...");
		}
		else
		{
			System.out.println("folder path is not valid...");
			//System system;
			//system.exit(0);
		}
		int countFile=0;
		countFile =folderPath.list().length;
		System.out.println("No of file in a given file folder path is "+ countFile);

	}

}
