//3. Using TDD approach Count the number of prime numbers in given array
package TwentyTwoSeptemberThirdAssignment;

import static org.junit.Assert.*;

import org.junit.Test;

public class CountPrimeNumberTest {

	CountPrimeNumber test= new CountPrimeNumber();
	@Test
	public void countPrimeNumberInArray() {
		int array[]= {1,2,3,4,5,6,7,8,9};
		int expected=4;
		int actual=test.primeNumber(array);
		assertEquals(expected, actual);
	}
	@Test
	public void countPrimeNumberSize() {
		int array[]= {};
		try
		{
			test.primeNumber(array);
			assertTrue(false);
		}
		catch(RuntimeException e)
		{
			assertTrue(true);
		}
	}
	

}
