//3. Using TDD approach Count the number of prime numbers in given array
package TwentyTwoSeptemberThirdAssignment;

public class CountPrimeNumber {
	
	public int primeNumber(int myArray[])
	{
		if(myArray.length==0)
		{
			throw new RuntimeException();
		}
		int count=0;
	
		for(int i=0;i<myArray.length;i++)
		{
		 
		 int m=0,flag=0;      
		    
		  m=myArray[i]/2;      
		  if(myArray[i]==0||myArray[i]==1)
		  {  
		   //System.out.println(myArray[i]+" is not prime number");      
		  }
		  else
		  {  
		   for(int j=2;j<=m;j++)
		   {      
		    if(myArray[i]%j==0)
		    {      
		    // System.out.println(myArray[i]+" is not prime number");      
		     flag=1;      
		     break;      
		    }      
		   }      
		   if(flag==0)  
		   {
			 // System.out.println(myArray[i]+" is prime number");
			   count++;
		   }
		   }  
		   
		}
		return count;
		 
	}
//	public static void main(String gg[])
//	{
//		int array[]= {1,2,3,4,5,6,7,8,9};
//		CountPrimeNumber prime= new CountPrimeNumber();
//		int primeCount=prime.primeNumber(array);
//		System.out.println(primeCount);
//	}

}
