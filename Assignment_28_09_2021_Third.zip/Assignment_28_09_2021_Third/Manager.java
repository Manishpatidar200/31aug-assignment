/*
  3. Create a class Employee with following attributes

    empId
    empFirstName
    empLastName
    empDOB
    empGender

  create subclass Manager of Employee with following attributes

   managerId

  Serialize object of manager except empDOB and deserialize and print details on console.
 */
package Assignment_28_09_2021_Third;

import java.io.Serializable;

public class Manager extends Employee implements Serializable{
	private int managerId;
	transient private String empDOB;
	
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getEmpDOB() {
		return empDOB;
	}

	public void setEmpDOB(String empDOB) {
		this.empDOB = empDOB;
	}

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + "]";
	}   

}
