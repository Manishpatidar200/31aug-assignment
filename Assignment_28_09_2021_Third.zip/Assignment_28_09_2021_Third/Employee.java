/*
  3. Create a class Employee with following attributes

    empId
    empFirstName
    empLastName
    empDOB
    empGender

  create subclass Manager of Employee with following attributes

   managerId

  Serialize object of manager except empDOB and deserialize and print details on console.
 */
package Assignment_28_09_2021_Third;

import java.io.Serializable;

public class Employee implements Serializable {
	private int empId;
    private String empFirstName;
    private String empLastName;
    private String empDOB;
    private String empGender;
    
    public Employee() {
		super();
	
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public String getEmpDOB() {
		return empDOB;
	}

	public void setEmpDOB(String empDOB) {
		this.empDOB = empDOB;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empDOB=" + empDOB + ", empGender=" + empGender + "]";
	}
    
    

}
