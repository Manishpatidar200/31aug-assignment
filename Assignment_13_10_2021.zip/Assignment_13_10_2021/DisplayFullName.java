package Assignment_13_10_2021;

import java.util.List;

public class DisplayFullName {
	public static void main(String[] args) {
		List<Student> students = Student.getStudents();
		System.out.println("************ Students Names **************");
		students
		.forEach(x->System.out.println(x.getFirstName().toUpperCase()+" "+x.getLastName().toUpperCase()));
		System.out.println("******************************************");
	}

}
