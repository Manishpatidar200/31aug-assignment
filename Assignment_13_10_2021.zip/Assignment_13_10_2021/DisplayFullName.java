/*
 * Using Stream API

1. get list of all the students whose firstname has a pattern 'ai"
2. Count the number of students whose firstname starts with "K"
3. Identify student wise which semester has highest score and which semester has least score.
4. Sort the students based on rollNo 
5. Display FullName of each student in uppercase

 */
package Assignment_13_10_2021;

import java.util.List;

public class DisplayFullName {
	public static void main(String[] args) {
		List<Student> students = Student.getStudents();
		System.out.println("************ Students Names **************");
		students
		.forEach(x->System.out.println(x.getFirstName().toUpperCase()+" "+x.getLastName().toUpperCase()));
		System.out.println("******************************************");
	}

}
