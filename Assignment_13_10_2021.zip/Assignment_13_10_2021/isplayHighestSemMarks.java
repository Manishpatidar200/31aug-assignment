/*
 * Using Stream API

1. get list of all the students whose firstname has a pattern 'ai"
2. Count the number of students whose firstname starts with "K"
3. Identify student wise which semester has highest score and which semester has least score.
4. Sort the students based on rollNo 
5. Display FullName of each student in uppercase

 */
package Assignment_13_10_2021;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

public class isplayHighestSemMarks {
	public static void main(String[] args) 
	{
		List<Student> students = Student.getStudents();
		students.forEach(x->{
			Map<String,Integer> map = new HashMap<>();
			System.out.println("************************** Student *************************************");
			map.put("Semester 1",x.getSem1Marks());
			map.put("Semester 2",x.getSem2Marks());
			map.put("Semester 3",x.getSem3Marks());
			map.put("Semester 4",x.getSem4Marks());
			map.put("Semester 5",x.getSem5Marks());
			map.put("Semester 6",x.getSem6Marks());
			Optional<Entry<String,Integer>> min = map
					.entrySet()
					.stream()
					.min((o1,o2)->o1.getValue().compareTo(o2.getValue()));
			Optional<Entry<String,Integer>> max = map
					.entrySet()
					.stream()
					.max((o1,o2)->o1.getValue().compareTo(o2.getValue()));
			
			System.out.println("Name : "+x.getFirstName()+" "+x.getLastName());
			System.out.println("Roll No : "+x.getRollNo());
			if(max.isPresent()) {
				System.out.println("Highest Marks : "+max.get().getValue() + " in "+max.get().getKey());				
			}
			if(min.isPresent()) {
				System.out.println("Lowest Marks : "+min.get().getValue() + " in "+min.get().getKey());				
			}
			System.out.println("************************************************************************");
		});
	}

}
