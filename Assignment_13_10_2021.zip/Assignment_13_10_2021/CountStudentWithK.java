package Assignment_13_10_2021;

import java.util.List;

public class CountStudentWithK {
	public static void main(String[] args) {
		List<Student> students = Student.getStudents();
		long count = students
		.stream()
		.filter(name->name.getFirstName().startsWith("K"))
		.count();
		
		System.out.println("Students count whose name starts with 'K' : "+count);
	}

}
