/*1. put student data into a file student.dat


	 101 sabbir 45 54 67 81 71 66
	 102 amit 95 66 62 88 79 63
	....

	Read data from student.dat and compute percentage of each student and sort student data based on percentage.
*/
package Assignment_28_09_2021_first;

	import java.nio.file.Files;
	import java.util.*;
	import java.io.File;

	public class StudentData {
		public static void main(String[] args) {

			ArrayList<String> name = new ArrayList<>();
			ArrayList<Double> mark = new ArrayList<>();
			ArrayList copy = new ArrayList();
			String s = "";
			try {

				String[] line = Files.readAllLines(new File(
						"D:\\\\programforTraining\\\\CoreJavaAssignment\\\\src\\\\Assignment_28_09_2021_first\\\\\\\\StudentData.dat")
								.toPath())
						.toArray(new String[0]);
				double no = 0;
				// System.out.println(line[0]);

				for (int i = 0; i < line.length; i++) {

					String[] strArray = line[i].split(" ");

					for (int j = 0; j < strArray.length; j++) {

						if (j >= 2) {
							s = strArray[j];
							no += Double.parseDouble(s);
							s = "";
						}
					}

					mark.add(no / 6);//

					// System.out.println(copy);//98/29/4
					name.add(strArray[1]);

					no = 0;
				}
				copy.addAll(mark);
				Collections.sort(mark);
				for (int x = 0; x < mark.size(); x++) {
					for (int v = 0; v < mark.size(); v++) {
						if (mark.get(x).equals(copy.get(v))) {
							System.out.println(name.get(v) + " " + copy.get(v));

						}

					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}


